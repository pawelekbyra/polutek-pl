# Universe Brain — brain of the codebase (v0.1 starter)

**Mission:** a portable and verifiable memory layer for coding agents, growing with every reviewed change. It is **not** a new language model and not automatic model training.

## What already works
- Detects changed files via SHA-256 and refreshes **only** modified file chunks.
- Deletes obsolete chunks when source files disappear.
- Follows .gitignore when indexing Git repositories; skips common secret/build/lock files.
- Searches text via SQLite FTS5, storing path and line ranges.
- Optional local sentence-transformers embeddings, cached per content hash, combined with lexical results by Reciprocal Rank Fusion.
- Local `watch` loop and optional `post-commit` hook for regular updates.
- Read-only MCP stdio server for **one explicitly authorized repository**.
- Automated unit tests in GitHub Actions.

## Installation and demo

Requirements: Python 3.10+, SQLite with FTS5. No cloud credentials needed for lexical search.

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
python -m pip install -e .
universe-brain index /path/to/your/repo
universe-brain search "verify payment" --repo /path/to/your/repo
universe-brain watch /path/to/your/repo --interval 5
```

Optional local embeddings (first use downloads a model; English-focused demo model, not a validated code model):

```bash
python -m pip install -e '.[vectors]'
universe-brain search "how payment verification works" --repo /path/to/your/repo --vectors
```

Optional MCP read-only server:

```bash
python -m pip install -e '.[mcp]'
export UNIVERSE_BRAIN_REPO=/path/to/your/repo
universe-brain mcp
```

Configure your MCP client to launch `universe-brain mcp` as a **stdio** process with the `UNIVERSE_BRAIN_REPO` environment variable. ChatGPT remote plugins require an authenticated HTTP MCP service, **not included yet**. Do **not** expose this stdio prototype as a public Internet API.

## Local automatic refresh

Use `universe-brain watch /path/to/your/repo` to detect local edits. Or for this starter's own repository enable post-commit indexing:

```bash
git config core.hooksPath .githooks
```

For repositories other than this project, configure an equivalent local post-commit hook there. This does **not** configure automatic remote GitHub webhook sync; that requires the v0.2 security and consistency work.

## Ground rules

1. Git and approved ADRs are the source of truth. Index can be rebuilt.
2. The index is **worktree-scoped**, not yet branch/commit snapshot isolated. Validate source before editing.
3. This version has **no code graph** and no independent proof of improvement over existing agent tools; these are next steps.
4. Embeddings carry confidential information; optional local model and storage are best used for non-secret files.
5. Embeddings are only hints. Agents must verify paths/lines against current repo.
6. No external model APIs are called by default. DB stays local at `~/.universe-brain/index.sqlite3`.

See `docs/ROADMAP.md` for the steps toward a production-grade, secure shared service.
