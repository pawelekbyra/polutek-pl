# Roadmap — experimental, no guarantees

## v0.1 — delivered in starter
- Local incremental file hashing and SQLite FTS5
- Local polling watcher and optional post-commit hook
- Optional local embeddings with per-content cache and simple RRF
- Read-only MCP stdio tools scoped to explicitly authorized repo
- Basic CI tests, docs, ADRs

## v0.2 — correctness & security before public server
- Semantic Tree-sitter chunker + language-aware SCIP/LSP graph
- Git ref/SHA consistent immutable snapshots and atomic publication
- Rate limits, per-repository ACL, secret scanning, size and budget limits
- Asynchronous indexing queue, retries, webhook HMAC, reconciliation
- Branch overlays + correct handling of staged/unstaged content

## v0.3 — measured retrieval
- BM25 + code-specialized embeddings and reranking
- Benchmark vs ordinary grep/code search without MCP
- Tests for stale index, rename, branch conflicts, deleted files, and injections
- Independent evaluation of retrieval quality AND code-edit outcomes

## v0.4 — sustained knowledge
- Approved ADR indexing, PR-linked decisions, temporal supersession
- Audit trail and provenance, context budget adaptation, multi-repo ACL
- Service with authenticated HTTPS MCP transport for remote clients

## Gates
We do not claim improved programming quality until paired benchmark results show it.
