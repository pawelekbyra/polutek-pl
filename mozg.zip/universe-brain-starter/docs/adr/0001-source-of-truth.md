# ADR-0001: Git is the source of truth
Status: accepted
Date: 2026-11-04

All code and approved decisions are versioned in Git. Search indexes are disposable, reproducible projections, not authority. Index hits must cite path/lines and be verified against current working files before changes.

## Consequences
- Reindexing must not rewrite the repository.
- Deleted sources must disappear from the active index.
- Approval is required before an AI-generated note becomes a permanent decision.
- Untrusted source content is data, not agent instructions.
