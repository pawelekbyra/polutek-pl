import tempfile
from pathlib import Path
import unittest
from universe_brain.indexer import connect, index_repository, line_chunks
from universe_brain.search import search

class IndexTests(unittest.TestCase):
    def test_incremental_update_and_deletion(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "repo"
            root.mkdir()
            db = Path(directory) / "memory.sqlite"
            code = root / "payments.py"
            code.write_text("def verify_payment():\n    return 'pending'\n")
            conn = connect(db)
            first = index_repository(root, conn)
            self.assertEqual(first["changed"], 1)
            self.assertEqual(first["files"], 1)
            second = index_repository(root, conn)
            self.assertEqual(second["changed"], 0)
            results = search(conn, root, "verify_payment")
            self.assertTrue(results)
            code.write_text("def verify_payment():\n    return 'paid'\n")
            third = index_repository(root, conn)
            self.assertEqual(third["changed"], 1)
            self.assertNotIn("pending", " ".join(x["content"] for x in search(conn, root, "verify_payment")))
            code.unlink()
            fourth = index_repository(root, conn)
            self.assertEqual(fourth["deleted"], 1)
            self.assertEqual(search(conn, root, "verify_payment"), [])
            conn.close()

    def test_python_ast_boundaries(self):
        code = "import math\n\ndef example():\n    return math.pi\n\ndef next_one():\n    return 2\n"
        chunks = line_chunks(code, ".py")
        self.assertGreaterEqual(len(chunks), 2)
        self.assertIn("def example", " ".join(c[2] for c in chunks))

    def test_secret_files_skipped(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)/"repo";root.mkdir()
            (root/".env").write_text("API_KEY=topsecret")
            (root/"readme.md").write_text("Something useful")
            conn = connect(Path(directory)/"db.sqlite")
            stats=index_repository(root,conn)
            self.assertEqual(stats["files"],1)
            conn.close()

if __name__ == "__main__": unittest.main()
