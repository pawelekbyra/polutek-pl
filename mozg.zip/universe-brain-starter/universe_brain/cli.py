"""Repository index CLI. No HTTP service is exposed by default."""
import argparse
import json
from pathlib import Path
import time
from .indexer import connect, index_repository, default_db
from .search import search, DEFAULT_MODEL


def main() -> None:
    parser = argparse.ArgumentParser(prog="universe-brain")
    parser.add_argument("--db", type=Path, default=default_db(), help="SQLite database path")
    sub = parser.add_subparsers(dest="command", required=True)
    p_index = sub.add_parser("index", help="Index a repo, updating only changed files")
    p_index.add_argument("repo", type=Path)
    p_search = sub.add_parser("search", help="Search an indexed repo")
    p_search.add_argument("query")
    p_search.add_argument("--repo", type=Path, default=Path.cwd())
    p_search.add_argument("--vectors", action="store_true", help="Optional local embeddings + RRF")
    p_search.add_argument("--model", default=DEFAULT_MODEL)
    p_search.add_argument("--limit", type=int, default=8)
    p_watch = sub.add_parser("watch", help="Poll local repo files, refreshing the index")
    p_watch.add_argument("repo", type=Path)
    p_watch.add_argument("--interval", type=float, default=5.0)
    sub.add_parser("mcp", help="Start read-only MCP server over stdio")
    args = parser.parse_args()
    if args.command == "mcp":
        from .mcp_server import serve
        serve(args.db)
        return
    conn = connect(args.db)
    if args.command == "index":
        print(json.dumps(index_repository(args.repo, conn), indent=2))
    elif args.command == "search":
        results = search(conn, args.repo, args.query, max(1, args.limit), args.vectors, args.model)
        for r in results:
            print(f"{r['path']}:{r['start_line']}-{r['end_line']}\n{r['content'][:500]}\n---")
    elif args.command == "watch":
        print("Watching local worktree. Ctrl+C to stop.", flush=True)
        try:
            while True:
                result = index_repository(args.repo, conn)
                if result["changed"] or result["deleted"]: print(json.dumps(result), flush=True)
                time.sleep(max(1.0, args.interval))
        except KeyboardInterrupt:
            pass

if __name__ == "__main__":
    main()
