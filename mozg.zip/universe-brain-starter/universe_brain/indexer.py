"""Incremental, privacy-conscious local code/doc indexing into SQLite FTS5.

The repository and its approved ADRs remain the source of truth. Index is disposable.
"""
from __future__ import annotations
import ast
import hashlib
import os
from pathlib import Path
import sqlite3
import subprocess

ALLOWED = {".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs", ".md", ".mdx", ".json", ".yaml", ".yml", ".toml", ".sql", ".sh", ".html", ".css", ".txt"}
SKIP_DIRS = {".git", "node_modules", "dist", "build", ".next", ".venv", "venv", "coverage", "vendor", "__pycache__", ".terraform", "target", "out", "data"}
SKIP_FILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "Cargo.lock", "poetry.lock", "uv.lock", "bun.lockb", "bun.lock", "id_rsa", "id_ed25519"}
MAX_SIZE = 300_000


def default_db() -> Path:
    return Path(os.environ.get("UNIVERSE_BRAIN_DB", "~/.universe-brain/index.sqlite3")).expanduser()


def connect(db: Path | None = None) -> sqlite3.Connection:
    path = db or default_db()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS files (
            repo TEXT NOT NULL, path TEXT NOT NULL, file_hash TEXT NOT NULL,
            PRIMARY KEY(repo, path)
        );
        CREATE TABLE IF NOT EXISTS chunks (
            id INTEGER PRIMARY KEY, repo TEXT NOT NULL, path TEXT NOT NULL,
            start_line INTEGER NOT NULL, end_line INTEGER NOT NULL,
            content TEXT NOT NULL, content_hash TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_chunks_repo_path ON chunks(repo, path);
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(content, path);
        CREATE TABLE IF NOT EXISTS embedding_cache (
            content_hash TEXT NOT NULL, model TEXT NOT NULL,
            vector_json TEXT NOT NULL,
            PRIMARY KEY(content_hash, model)
        );
    """)
    return conn


def is_allowed(rel: Path) -> bool:
    parts = rel.parts
    name = rel.name
    if any(p in SKIP_DIRS or p.startswith(".env") for p in parts):
        return False
    if name in SKIP_FILES or name.startswith(".env") or name.endswith((".pem", ".key", ".p12", ".pfx")):
        return False
    return rel.suffix.lower() in ALLOWED


def paths_in_repo(root: Path) -> list[Path]:
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
            capture_output=True, check=True, timeout=15
        )
        names = [os.fsdecode(n) for n in result.stdout.split(b"\0") if n]
        return sorted({Path(n) for n in names if is_allowed(Path(n))})
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        found = []
        for base, dirs, names in os.walk(root):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".env")]
            for name in names:
                rel = (Path(base) / name).relative_to(root)
                if is_allowed(rel): found.append(rel)
        return sorted(found)


def line_chunks(source: str, extension: str, target_lines: int = 70) -> list[tuple[int, int, str]]:
    lines = source.splitlines()
    if not lines: return []
    boundaries = {1, len(lines) + 1}
    if extension == ".py":
        try:
            parsed = ast.parse(source)
            for node in parsed.body:
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    boundaries.add(node.lineno)
                    boundaries.add(node.end_lineno + 1)
        except SyntaxError: pass  # still index incomplete code as text
    else:
        # Conservative text fallback. Future phases add Tree-sitter language parsers.
        for i, line in enumerate(lines, 1):
            if line.startswith(("## ", "### ", "export function ", "export class ", "function ", "class ")):
                boundaries.add(i)
    points = sorted(boundaries)
    spans = []
    for a, b in zip(points, points[1:]):
        p = a
        while p < b:
            end = min(p + target_lines, b)
            piece = "\n".join(lines[p-1:end-1])
            if piece.strip(): spans.append((p, end-1, piece))
            p = end
    return spans


def _remove_file(conn: sqlite3.Connection, repo: str, path: str) -> None:
    rows = conn.execute("SELECT id FROM chunks WHERE repo=? AND path=?", (repo, path)).fetchall()
    for row in rows:
        conn.execute("DELETE FROM chunks_fts WHERE rowid=?", (row["id"],))
    conn.execute("DELETE FROM chunks WHERE repo=? AND path=?", (repo, path))
    conn.execute("DELETE FROM files WHERE repo=? AND path=?", (repo, path))


def index_repository(root: Path, conn: sqlite3.Connection) -> dict:
    root = root.expanduser().resolve(strict=True)
    if not root.is_dir(): raise NotADirectoryError(root)
    repo = str(root)
    seen: set[str] = set()
    changed = 0
    unchanged = 0
    for rel in paths_in_repo(root):
        path = (root / rel).resolve()
        if not path.is_file() or not path.is_relative_to(root) or path.stat().st_size > MAX_SIZE:
            continue
        try:
            data = path.read_bytes()
            if b"\0" in data: continue
            source = data.decode("utf-8")
        except (OSError, UnicodeError):
            continue
        name = rel.as_posix()
        seen.add(name)
        digest = hashlib.sha256(data).hexdigest()
        record = conn.execute("SELECT file_hash FROM files WHERE repo=? AND path=?", (repo, name)).fetchone()
        if record and record["file_hash"] == digest:
            unchanged += 1
            continue
        with conn:
            _remove_file(conn, repo, name)
            for a, b, content in line_chunks(source, rel.suffix.lower()):
                content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
                cur = conn.execute("INSERT INTO chunks(repo,path,start_line,end_line,content,content_hash) VALUES(?,?,?,?,?,?)", (repo, name, a, b, content, content_hash))
                conn.execute("INSERT INTO chunks_fts(rowid, content, path) VALUES(?,?,?)", (cur.lastrowid, content, name))
            conn.execute("INSERT INTO files(repo,path,file_hash) VALUES(?,?,?)", (repo, name, digest))
        changed += 1
    existing = {row["path"] for row in conn.execute("SELECT path FROM files WHERE repo=?", (repo,))}
    removed = existing - seen
    with conn:
        for name in removed:
            _remove_file(conn, repo, name)
    return {"repo": repo, "changed": changed, "unchanged": unchanged, "deleted": len(removed), "files": len(seen)}
