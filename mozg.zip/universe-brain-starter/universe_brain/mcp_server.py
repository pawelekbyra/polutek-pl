"""Read-only MCP stdio tool server for a single allowlisted repository.

Set UNIVERSE_BRAIN_REPO to the indexed repo directory before starting.
Do not connect to untrusted repositories or expose this process to the Internet.
"""
from pathlib import Path
import os
from .indexer import connect
from .search import search, DEFAULT_MODEL


def serve(db: Path) -> None:
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise SystemExit("MCP extra required: pip install -e '.[mcp]'") from exc
    path = os.environ.get("UNIVERSE_BRAIN_REPO")
    if not path:
        raise SystemExit("Set UNIVERSE_BRAIN_REPO to one explicitly authorized repository")
    root = Path(path).expanduser().resolve(strict=True)
    app = FastMCP("universe-brain")

    @app.tool()
    def search_code(query: str, limit: int = 8, vectors: bool = False) -> list[dict]:
        """Search authorized repository code/docs. Returns paths, lines and evidence from local index."""
        conn = connect(db)
        try:
            hits = search(conn, root, query, max(1, min(limit, 20)), vectors, DEFAULT_MODEL)
            return [{"path": h["path"], "line_start": h["start_line"], "line_end": h["end_line"], "content": h["content"], "score": h.get("rrf_score", h.get("score"))} for h in hits]
        finally:
            conn.close()

    @app.tool()
    def index_status() -> dict:
        """Show number of indexed files/chunks in the authorized repository."""
        conn = connect(db)
        try:
            repo = str(root)
            files = conn.execute("SELECT COUNT(*) FROM files WHERE repo=?", (repo,)).fetchone()[0]
            chunks = conn.execute("SELECT COUNT(*) FROM chunks WHERE repo=?", (repo,)).fetchone()[0]
            return {"repo": repo, "files": files, "chunks": chunks, "warning": "Index is a hint; verify current local code before making edits."}
        finally: conn.close()

    app.run(transport="stdio")
