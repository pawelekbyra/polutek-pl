"""Exact lexical search + optional local embedding retrieval, merged with RRF."""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
from .indexer import connect

DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"  # demonstrator only; evaluate a code-capable model before production


def lexical(conn: sqlite3.Connection, repo: str, query: str, limit: int = 10) -> list[dict]:
    tokens = re.findall(r"\w+", query, re.UNICODE)[:24]
    if not tokens: return []
    expression = " OR ".join('"' + t.replace('"', '') + '"' for t in tokens)
    sql = """
        SELECT c.id, c.path, c.start_line, c.end_line, c.content, c.content_hash,
               bm25(chunks_fts) AS score
        FROM chunks_fts JOIN chunks c ON chunks_fts.rowid=c.id
        WHERE chunks_fts MATCH ? AND c.repo=? ORDER BY score LIMIT ?
    """
    return [dict(r) for r in conn.execute(sql, (expression, repo, limit))]


def _cosine(a: list[float], b: list[float]) -> float:
    if len(a) != len(b): return -1.0
    den = math.sqrt(sum(x*x for x in a)) * math.sqrt(sum(y*y for y in b))
    return sum(x*y for x, y in zip(a, b)) / den if den else -1.0


def semantic(conn: sqlite3.Connection, repo: str, query: str, limit: int, model: str = DEFAULT_MODEL) -> list[dict]:
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as e:
        raise RuntimeError("Install optional vector dependencies: pip install -e '.[vectors]'") from e
    encoder = SentenceTransformer(model)
    query_vector = encoder.encode([query], normalize_embeddings=True)[0].tolist()
    rows = list(conn.execute("SELECT id, path, start_line, end_line, content, content_hash FROM chunks WHERE repo=?", (repo,)))
    missing = {}
    for row in rows:
        key = row["content_hash"]
        cached = conn.execute("SELECT vector_json FROM embedding_cache WHERE content_hash=? AND model=?", (key, model)).fetchone()
        if not cached: missing[key] = row["content"]
    if missing:
        keys = list(missing)
        vectors = encoder.encode([missing[k] for k in keys], normalize_embeddings=True, show_progress_bar=False)
        with conn:
            conn.executemany("INSERT OR IGNORE INTO embedding_cache(content_hash,model,vector_json) VALUES(?,?,?)", [(key, model, json.dumps(v.tolist())) for key,v in zip(keys,vectors)])
    vector_map = {r["content_hash"]: json.loads(r["vector_json"]) for r in conn.execute("SELECT content_hash,vector_json FROM embedding_cache WHERE model=?", (model,))}
    scored = []
    for row in rows:
        v = vector_map.get(row["content_hash"])
        if v is None: continue
        item = dict(row)
        item["score"] = _cosine(query_vector, v)
        scored.append(item)
    return sorted(scored, key=lambda x:x["score"], reverse=True)[:limit]


def search(conn: sqlite3.Connection, root: Path, query: str, limit: int = 8, use_vectors: bool = False, model: str = DEFAULT_MODEL) -> list[dict]:
    repo = str(root.expanduser().resolve())
    exact = lexical(conn, repo, query, max(20, limit*3))
    if not use_vectors:
        return exact[:limit]
    semantic_hits = semantic(conn, repo, query, max(20, limit*3), model)
    combined: dict[int, dict] = {}
    for hits in (exact, semantic_hits):
        for rank, row in enumerate(hits, 1):
            entry = combined.setdefault(row["id"], dict(row, rrf_score=0.0))
            entry["rrf_score"] += 1 / (60 + rank)
    return sorted(combined.values(), key=lambda x:x["rrf_score"], reverse=True)[:limit]
