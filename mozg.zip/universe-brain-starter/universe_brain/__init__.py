"""Universe Brain — a reproducible repository knowledge prototype."""
__version__ = "0.1.0"
